package servlet;
import DAO.UserDAOImpl;
import DB.DBConnection;
import entity.UserDtls;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/insertServlet")
public class InsertServlet extends javax.servlet.http.HttpServlet {
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {



        try {
            String id = request.getParameter("id");
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String batch = request.getParameter("batch");
            String pass = request.getParameter("pass");
            String phone = request.getParameter("phone");
            String ctown = request.getParameter("ctown");
            String ptown = request.getParameter("ptown");
            String grad = request.getParameter("grad");
            String sex = request.getParameter("sex");
            String job = request.getParameter("job");
            String jdtls = request.getParameter("jdtls");
            String flink = request.getParameter("flink");
            String ilink = request.getParameter("ilink");
            String llink = request.getParameter("llink");



            System.out.println(id + " " + name + " " + email + " " +batch+" " + pass + " " + phone + " " + ctown + " " + ptown + " " + grad + " " + sex + " " + job +  " " + jdtls +  " " + flink + " " + ilink + " " + llink );
            UserDtls userDtls = new UserDtls(id,name,email,batch,pass,phone,ctown,ptown,grad,sex,job,jdtls,flink,ilink,llink);
            UserDAOImpl userDAO = new UserDAOImpl(DBConnection.getConn());
            boolean f = userDAO.insertUser(userDtls);
            System.out.println("ekahne kaj korse");
            HttpSession session = request.getSession();
            if (f){
                session.setAttribute("succMsg" ,"Your registration is complete...");
                response.sendRedirect("insert.jsp");
            }else {
                session.setAttribute("failedMsg" ,"User details not insert..");
                response.sendRedirect("insert.jsp");

            }

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {

    }
}
